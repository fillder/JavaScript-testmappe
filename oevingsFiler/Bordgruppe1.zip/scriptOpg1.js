let vafler = 10;
let vaflerTekst = document.getElementById("antallVafler");

function selgVafler() {}
